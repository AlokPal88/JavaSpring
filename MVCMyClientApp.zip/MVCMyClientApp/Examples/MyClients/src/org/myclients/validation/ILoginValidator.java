package org.myclients.validation;

import org.myclients.domain.Login;
import org.myclients.validation.common.IValidationContext;

public interface ILoginValidator {

	void validateForSave(Login target, IValidationContext context);
	void validateForMerge(Login target, IValidationContext context);
}