package org.myclients.validation.common;

public interface IValidationContextFactory {

	IValidationContext getNew();
}