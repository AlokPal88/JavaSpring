package org.myclients.validation.impl;

import org.myclients.domain.Login;
import org.myclients.validation.ILoginValidator;
import org.myclients.validation.common.IValidationContext;
import org.springframework.stereotype.Service;

@Service
public class LoginValidator implements ILoginValidator {

	@Override
	public void validateForSave(Login target, IValidationContext context) {

		context.setField("id", target.getId());
		context.missing();
		
		context.setField("name", target.getName());
		context.required();
		context.text();
		
		context.setField("password", target.getPassword());
		context.required();
		context.text();
		
		context.setField("enabled", target.getEnabled());
		context.trueFalse();
		
		context.setField("client", target.getClient());
		context.missing();
	}

	@Override
	public void validateForMerge(Login target, IValidationContext context) {

		context.setField("id", target.getId());
		if (context.isAssigned())
		{
			context.number();
		}

		context.setField("name", target.getName());
		context.required();
		context.text();
		
		context.setField("password", target.getPassword());
		context.required();
		context.text();
		
		context.setField("enabled", target.getEnabled());
		context.trueFalse();
		
		context.setField("client", target.getClient());
		context.missing();
	}
}