package org.myclients.validation;

import org.myclients.domain.Client;
import org.myclients.validation.common.IValidationContext;

public interface IClientValidator {

	void validateForSave(Client target, IValidationContext context);
	void validateForUpdate(Client target, IValidationContext context);
}