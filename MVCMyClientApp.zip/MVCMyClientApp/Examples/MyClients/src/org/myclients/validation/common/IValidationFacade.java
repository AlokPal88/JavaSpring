package org.myclients.validation.common;

import org.myclients.domain.Client;

public interface IValidationFacade {

	void assertClientForSave(Client target);
	void assertClientForUpdate(Client target);
	void assertClientExists(Client item);
	void assertMoreThanOneClient(long count);
}