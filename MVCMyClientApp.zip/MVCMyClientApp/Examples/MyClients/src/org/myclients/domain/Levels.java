package org.myclients.domain;

public class Levels {

	public static final byte ID = 1;
	public static final byte LOOKUP = 2;
	public static final byte GRID = 3;
	public static final byte DEEP = 4;
	public static final byte NEVER = 100;
}